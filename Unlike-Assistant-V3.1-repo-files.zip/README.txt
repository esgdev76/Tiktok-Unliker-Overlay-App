Unlike Assistant V3.1 - files for your GitHub repo

Copy the folders in this zip over your project (merge, overwrite when asked):
  app/src/main/java/com/example/tiktokunlikeassistant/   <- 4 Java files
  app/src/main/res/xml/accessibility_service_config.xml
  app/src/main/res/values/strings.xml

IMPORTANT: delete the old Kotlin files in the same package first
(MainActivity.kt, OverlayService.kt, TikTokAccessibilityService.kt, and the QueuedTile class),
otherwise the build fails with duplicate classes.

AndroidManifest.xml does not change. No extra dependencies are needed.
Release: upload the APK (Unlike-Assistant-V3.1.apk) as an asset on your GitHub release.
