package com.example.tiktokunlikeassistant;

import android.graphics.Rect;

/** One selected liked-video tile (screen coordinates at the moment it was selected). */
final class Tile {
    final int x;
    final int y;
    final Rect rect; // may be null when the tile bounds could not be read from the accessibility tree

    Tile(int x, int y, Rect rect) {
        this.x = x;
        this.y = y;
        this.rect = rect;
    }
}
