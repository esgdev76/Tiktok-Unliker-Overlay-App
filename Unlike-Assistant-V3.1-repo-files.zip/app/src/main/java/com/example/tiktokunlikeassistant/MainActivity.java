package com.example.tiktokunlikeassistant;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {

    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int p = dp(20);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(p, dp(28), p, p);
        root.setBackgroundColor(0xFF111114);

        TextView title = new TextView(this);
        title.setText("Unlike Assistant");
        title.setTextSize(28f);
        title.setTextColor(Color.WHITE);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("Floating circle menu • Select • Start • Exit");
        sub.setTextSize(14f);
        sub.setTextColor(0xFFB8B8C2);
        sub.setPadding(0, dp(4), 0, dp(14));
        root.addView(sub);

        status = new TextView(this);
        status.setTextSize(13f);
        status.setTextColor(0xFFDDDDE6);
        status.setPadding(0, 0, 0, dp(10));
        root.addView(status);

        addButton(root, "1. Enable Accessibility", 0xFF2D2D36, new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });
        addButton(root, "1b. Accessibility greyed out? Allow restricted settings", 0xFF2D2D36, new Runnable() {
            @Override
            public void run() {
                // App info -> top-right menu (three dots) -> "Allow restricted settings"
                startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName())));
            }
        });
        addButton(root, "2. Allow floating icon", 0xFF2D2D36, new Runnable() {
            @Override
            public void run() {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                }
            }
        });
        addButton(root, "3. Start floating icon", 0xFF1F7A45, new Runnable() {
            @Override
            public void run() {
                if (Settings.canDrawOverlays(MainActivity.this)) {
                    startService(new Intent(MainActivity.this, OverlayService.class));
                    moveTaskToBack(true);
                } else {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                }
            }
        });
        addButton(root, "EXIT - stop everything & kill app", 0xFFC62828, new Runnable() {
            @Override
            public void run() {
                finishAndRemoveTask();
                OverlayService.exitEverything(MainActivity.this);
            }
        });

        TextView how = new TextView(this);
        how.setText("If Accessibility shows OFF even after you switched it on, or the switch is greyed out: press 1b, tap the three dots (top right) and choose \"Allow restricted settings\", then do step 1 again. Android blocks this for apps installed from a file.\n\n"
                + "How to use\n"
                + "1. Open TikTok → Profile → Liked videos.\n"
                + "2. Tap the floating bubble. The controls open as a circle around it. Drag the bubble to move it.\n"
                + "3. Tap Select, then tap the videos you want to unlike. They are only marked, nothing opens. Tap a marked video again to unmark it.\n"
                + "4. Tap the bubble again and press Start. The assistant opens each marked video, unlikes it, goes back, and checks that the heart really turned off.\n"
                + "5. Select and Start per screen. If you scroll while selecting, the marks are cleared.\n"
                + "6. Stop halts a run. Exit switches the assistant off completely and kills the app.");
        how.setTextSize(14f);
        how.setTextColor(0xFFC9C9D4);
        how.setLineSpacing(0, 1.15f);
        how.setPadding(0, dp(16), 0, 0);
        root.addView(how);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF111114);
        sv.addView(root);
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean acc = TikTokAccessibilityService.getInstance() != null;
        boolean ovl = Settings.canDrawOverlays(this);
        String t = (acc ? "\u2705 Accessibility: ON" : "\u274C Accessibility: OFF  (Select/Start will NOT work)")
                + "\n" + (ovl ? "\u2705 Floating permission: ON" : "\u274C Floating permission: OFF");
        status.setText(t);
        status.setTextColor(acc && ovl ? 0xFF7DDC9A : 0xFFFF8A80);
    }

    private void addButton(LinearLayout root, String label, int color, final Runnable action) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(dp(12));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(8);
        b.setLayoutParams(lp);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                action.run();
            }
        });
        root.addView(b);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
