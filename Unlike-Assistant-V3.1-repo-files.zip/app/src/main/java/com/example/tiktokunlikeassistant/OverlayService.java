package com.example.tiktokunlikeassistant;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.util.List;

/**
 * Floating bubble. Tap it and the controls fan out around it as a circle of round buttons.
 * Drag the bubble (or the ring) to move everything.
 */
public final class OverlayService extends Service implements TikTokAccessibilityService.Listener {

    private static volatile OverlayService instance;

    private static final int TYPE_OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
    // never focusable: a focusable overlay steals the "active window" from TikTok (that was the original bug)
    private static final int BASE_FLAGS = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS;

    private static final int BTN_SELECT = 0, BTN_DONE = 1, BTN_START = 2, BTN_STOP = 3, BTN_CLEAR = 4, BTN_EXIT = 5;
    private static final String[] LABELS = {"Select", "Done", "Start", "Stop", "Clear", "Exit"};
    private static final int[] COLORS = {0xFF2979FF, 0xFF00A383, 0xFF2EAD5B, 0xFFE8890C, 0xFF6C7A89, 0xFFE53935};

    private WindowManager wm;
    private Handler main;

    private FrameLayout menuRoot;
    private WindowManager.LayoutParams menuLp;
    private BubbleView bubble;
    private final RoundButton[] buttons = new RoundButton[6];
    private boolean expanded;
    private int cx, cy; // centre of the bubble in screen pixels

    private SelectView selView;
    private WindowManager.LayoutParams selLp;
    private boolean selecting;

    private int bubbleSize, itemSize, ringRadius, halfExt;
    private int screenW, screenH;

    // ------------------------------------------------------------------ lifecycle

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        main = new Handler(Looper.getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        bubbleSize = dp(56);
        itemSize = dp(52);
        ringRadius = dp(92);
        halfExt = ringRadius + itemSize / 2 + dp(4);
        readScreen();
        cx = dp(44);
        cy = Math.min(screenH / 3, dp(260));
        buildMenu();
        TikTokAccessibilityService.setListener(this);
        refresh();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // NOT sticky: if the process is killed Android must not bring the overlay back on its own
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        removeSelectView();
        if (menuRoot != null) {
            try {
                wm.removeViewImmediate(menuRoot);
            } catch (Throwable ignored) {
            }
            menuRoot = null;
        }
        TikTokAccessibilityService.setListener(null);
        instance = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ EXIT: really kill everything

    public static void exitEverything(final Context ctx) {
        TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
        if (svc != null) {
            svc.stopQueue(false);
            try {
                svc.disableSelf(); // switches the accessibility service off so Android can't restart it
            } catch (Throwable ignored) {
            }
        }
        OverlayService s = instance;
        if (s != null) {
            s.removeSelectView();
            s.stopSelf();
        }
        try {
            ctx.stopService(new Intent(ctx, OverlayService.class));
        } catch (Throwable ignored) {
        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Process.killProcess(Process.myPid());
                System.exit(0);
            }
        }, 350);
    }

    // ------------------------------------------------------------------ used by the accessibility service

    /** While true our menu lets every touch fall through to the app below (used during injected taps). */
    public static void setPassThrough(final boolean on) {
        final OverlayService s = instance;
        if (s == null) return;
        s.main.post(new Runnable() {
            @Override
            public void run() {
                if (s.menuRoot == null || s.menuLp == null) return;
                if (on) s.menuLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                else s.menuLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
                try {
                    s.wm.updateViewLayout(s.menuRoot, s.menuLp);
                } catch (Throwable ignored) {
                }
            }
        });
    }

    @Override
    public void onStateChanged() {
        refresh();
    }

    // ------------------------------------------------------------------ menu

    private void buildMenu() {
        menuRoot = new FrameLayout(this);
        bubble = new BubbleView(this);
        for (int i = 0; i < buttons.length; i++) {
            buttons[i] = new RoundButton(this, i);
            final int id = i;
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onButton(id);
                }
            });
            menuRoot.addView(buttons[i]);
        }
        menuRoot.addView(bubble);

        DragTouch bubbleTouch = new DragTouch(true);
        bubble.setOnTouchListener(bubbleTouch);
        menuRoot.setOnTouchListener(new DragTouch(false));

        menuLp = new WindowManager.LayoutParams(bubbleSize, bubbleSize, TYPE_OVERLAY,
                BASE_FLAGS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT);
        menuLp.gravity = Gravity.TOP | Gravity.START;
        layoutMenu();
        wm.addView(menuRoot, menuLp);
    }

    private void layoutMenu() {
        int size = expanded ? 2 * halfExt : bubbleSize;
        int margin = size / 2;
        cx = Math.max(margin, Math.min(screenW - margin, cx));
        cy = Math.max(margin, Math.min(screenH - margin, cy));

        menuLp.width = size;
        menuLp.height = size;
        menuLp.x = cx - size / 2;
        menuLp.y = cy - size / 2;

        FrameLayout.LayoutParams bl = new FrameLayout.LayoutParams(bubbleSize, bubbleSize);
        bl.leftMargin = size / 2 - bubbleSize / 2;
        bl.topMargin = size / 2 - bubbleSize / 2;
        bubble.setLayoutParams(bl);

        for (int i = 0; i < buttons.length; i++) {
            double ang = Math.toRadians(-90 + i * (360.0 / buttons.length));
            int ix = (int) (size / 2 + ringRadius * Math.cos(ang)) - itemSize / 2;
            int iy = (int) (size / 2 + ringRadius * Math.sin(ang)) - itemSize / 2;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(itemSize, itemSize);
            lp.leftMargin = ix;
            lp.topMargin = iy;
            buttons[i].setLayoutParams(lp);
            buttons[i].setVisibility(expanded ? View.VISIBLE : View.GONE);
        }

        if (expanded) {
            GradientDrawable disc = new GradientDrawable();
            disc.setShape(GradientDrawable.OVAL);
            disc.setColor(0x66101418);
            disc.setStroke(dp(1), 0x33FFFFFF);
            menuRoot.setBackground(disc);
        } else {
            menuRoot.setBackground(null);
        }
        try {
            wm.updateViewLayout(menuRoot, menuLp);
        } catch (Throwable ignored) {
        }
    }

    private void setExpanded(boolean e) {
        expanded = e;
        layoutMenu();
        refresh();
    }

    private void refresh() {
        if (bubble == null) return;
        TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
        boolean running = svc != null && svc.isRunning();
        int count = svc != null ? svc.queueSize() : 0;
        bubble.setState(count, selecting, running);
        buttons[BTN_SELECT].setActive(selecting);
        buttons[BTN_START].setActive(running);
        buttons[BTN_SELECT].setDim(running);
        buttons[BTN_DONE].setDim(!selecting);
        buttons[BTN_START].setDim(running || count == 0);
        buttons[BTN_STOP].setDim(!running);
        buttons[BTN_CLEAR].setDim(count == 0 && !running);
        if (selView != null) selView.invalidate();
    }

    private void needAccessibility() {
        toast("Accessibility is OFF for this app. Opening settings: turn on 'TikTok Unlike Assistant'.");
        try {
            Intent i = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Throwable ignored) {
        }
    }

    private void onButton(int id) {
        try {
            handleButton(id);
        } catch (Throwable t) {
            toast("Error: " + t);
        }
    }

    private void handleButton(int id) {
        TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
        switch (id) {
            case BTN_SELECT:
                if (svc == null) {
                    needAccessibility();
                    return;
                }
                if (svc.isRunning()) {
                    toast("Stop the run first.");
                    return;
                }
                addSelectView();
                selecting = true;
                setExpanded(false); // get the ring out of the way so you can tap videos
                toast("Tap the videos you want to unlike. Tap again to unmark. Open the bubble for Done / Start.");
                break;
            case BTN_DONE:
                removeSelectView();
                selecting = false;
                refresh();
                break;
            case BTN_START:
                if (svc == null) {
                    needAccessibility();
                    return;
                }
                if (svc.queueSize() == 0) {
                    toast("Nothing selected yet. Use Select first.");
                    return;
                }
                removeSelectView();
                selecting = false;
                setExpanded(false);
                svc.startQueue();
                break;
            case BTN_STOP:
                if (svc != null) svc.stopQueue(true);
                setExpanded(false);
                break;
            case BTN_CLEAR:
                if (svc != null) svc.clearQueue();
                refresh();
                break;
            case BTN_EXIT:
                toast("Closing Unlike Assistant");
                exitEverything(this);
                break;
        }
    }

    // ------------------------------------------------------------------ select mode (no more opening the video)

    private void addSelectView() {
        if (selView != null) return;
        selView = new SelectView(this);
        selLp = new WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT, TYPE_OVERLAY, BASE_FLAGS, PixelFormat.TRANSLUCENT);
        selLp.gravity = Gravity.TOP | Gravity.START;
        wm.addView(selView, selLp);
        // keep the bubble above the capture layer (after the current click is done)
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    if (menuRoot != null && selView != null) {
                        wm.removeViewImmediate(menuRoot);
                        wm.addView(menuRoot, menuLp);
                    }
                } catch (Throwable ignored) {
                }
            }
        }, 60);
    }

    private void removeSelectView() {
        if (selView != null) {
            try {
                wm.removeViewImmediate(selView);
            } catch (Throwable ignored) {
            }
            selView = null;
        }
    }

    private void setSelectTouchable(boolean touchable) {
        if (selView == null || selLp == null) return;
        if (touchable) selLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else selLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try {
            wm.updateViewLayout(selView, selLp);
        } catch (Throwable ignored) {
        }
    }

    private void onSelectTap(float x, float y) {
        TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
        if (svc == null) {
            toast("Accessibility service is off.");
            return;
        }
        svc.toggleTile((int) x, (int) y);
        refresh();
    }

    private void onSelectSwipe(final float x0, final float y0, final float x1, final float y1, final long dur) {
        final TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
        if (svc == null) return;
        if (svc.queueSize() > 0) {
            // marks are screen positions, so they would point at the wrong videos after scrolling
            svc.clearQueue();
            toast("Scrolled - marks cleared. Select, then Start, per screen.");
        }
        setSelectTouchable(false);
        main.postDelayed(new Runnable() {
            @Override
            public void run() {
                svc.swipe(x0, y0, x1, y1, dur, new Runnable() {
                    @Override
                    public void run() {
                        main.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                setSelectTouchable(true);
                            }
                        }, 120);
                    }
                });
            }
        }, 80);
        main.postDelayed(new Runnable() { // safety net
            @Override
            public void run() {
                setSelectTouchable(true);
            }
        }, 2500);
    }

    // ------------------------------------------------------------------ small helpers

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void readScreen() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
    }

    // ------------------------------------------------------------------ views

    /** Drags the whole menu. The bubble itself also toggles the ring on a plain tap. */
    private final class DragTouch implements View.OnTouchListener {
        private final boolean toggles;
        private float downX, downY;
        private int startCx, startCy;
        private boolean dragged;
        private final int slop = ViewConfiguration.get(OverlayService.this).getScaledTouchSlop();

        DragTouch(boolean toggles) {
            this.toggles = toggles;
        }

        @Override
        public boolean onTouch(View v, MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    startCx = cx;
                    startCy = cy;
                    dragged = false;
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) dragged = true;
                    if (dragged) {
                        cx = startCx + (int) dx;
                        cy = startCy + (int) dy;
                        layoutMenu();
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (!dragged && toggles) setExpanded(!expanded);
                    return true;
                default:
                    return true;
            }
        }
    }

    /** The round main button: app icon, a ring that shows the state, and a queue counter. */
    private final class BubbleView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badge = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint badgeText = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Path clip = new Path();
        private Drawable icon;
        private int count;
        private boolean selectingState, runningState;

        BubbleView(Context c) {
            super(c);
            fill.setColor(0xFF121212);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(dp(3));
            badge.setColor(0xFFFF2D55);
            badgeText.setColor(Color.WHITE);
            badgeText.setTextAlign(Paint.Align.CENTER);
            badgeText.setFakeBoldText(true);
            badgeText.setTextSize(dp(11));
            try {
                int id = getResources().getIdentifier("ic_launcher", "mipmap", getPackageName());
                if (id != 0) icon = getResources().getDrawable(id, getTheme());
            } catch (Throwable ignored) {
            }
            setElevation(dp(8));
            setContentDescription("Unlike Assistant. Tap to open the controls, drag to move.");
        }

        void setState(int count, boolean selecting, boolean running) {
            this.count = count;
            this.selectingState = selecting;
            this.runningState = running;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(2);
            c.drawCircle(w / 2, h / 2, r, fill);
            if (icon != null) {
                int pad = dp(6);
                clip.reset();
                clip.addCircle(w / 2, h / 2, r - dp(2), Path.Direction.CW);
                c.save();
                c.clipPath(clip);
                icon.setBounds(pad, pad, (int) w - pad, (int) h - pad);
                icon.draw(c);
                c.restore();
            }
            ring.setColor(runningState ? 0xFFFFA000 : selectingState ? 0xFF2ECC71 : 0xFFFF2D55);
            c.drawCircle(w / 2, h / 2, r, ring);
            if (count > 0) {
                float br = dp(10);
                float bx = w - br - dp(1), by = br + dp(1);
                c.drawCircle(bx, by, br, badge);
                c.drawText(String.valueOf(count), bx, by + dp(4), badgeText);
            }
        }
    }

    /** One round menu button with a drawn icon and a tiny label. */
    private final class RoundButton extends View {
        private final int type;
        private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint solid = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint activeRing = new Paint(Paint.ANTI_ALIAS_FLAG);
        private boolean active, dim;

        RoundButton(Context c, int type) {
            super(c);
            this.type = type;
            bg.setColor(COLORS[type]);
            stroke.setColor(Color.WHITE);
            stroke.setStyle(Paint.Style.STROKE);
            stroke.setStrokeWidth(dp(2));
            stroke.setStrokeCap(Paint.Cap.ROUND);
            stroke.setStrokeJoin(Paint.Join.ROUND);
            solid.setColor(Color.WHITE);
            text.setColor(Color.WHITE);
            text.setTextAlign(Paint.Align.CENTER);
            text.setFakeBoldText(true);
            text.setTextSize(dp(9));
            activeRing.setColor(Color.WHITE);
            activeRing.setStyle(Paint.Style.STROKE);
            activeRing.setStrokeWidth(dp(3));
            setElevation(dp(4));
            setContentDescription(LABELS[type]);
        }

        void setActive(boolean a) {
            active = a;
            invalidate();
        }

        void setDim(boolean d) {
            dim = d;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float w = getWidth(), h = getHeight();
            float r = Math.min(w, h) / 2f - dp(2);
            bg.setAlpha(dim ? 110 : 255);
            c.drawCircle(w / 2, h / 2, r, bg);
            if (active) c.drawCircle(w / 2, h / 2, r - dp(1), activeRing);
            int a = dim ? 150 : 255;
            stroke.setAlpha(a);
            solid.setAlpha(a);
            text.setAlpha(a);

            float ix = w / 2f, iy = h * 0.38f, s = dp(8);
            switch (type) {
                case BTN_SELECT: { // dashed selection box with a tick
                    Paint p = new Paint(stroke);
                    p.setPathEffect(new DashPathEffect(new float[]{dp(3), dp(3)}, 0));
                    c.drawRoundRect(new RectF(ix - s, iy - s, ix + s, iy + s), dp(2), dp(2), p);
                    c.drawLine(ix - s * 0.45f, iy, ix - s * 0.1f, iy + s * 0.4f, stroke);
                    c.drawLine(ix - s * 0.1f, iy + s * 0.4f, ix + s * 0.5f, iy - s * 0.4f, stroke);
                    break;
                }
                case BTN_DONE: { // bold tick
                    Paint p = new Paint(stroke);
                    p.setStrokeWidth(dp(3));
                    c.drawLine(ix - s, iy, ix - s * 0.3f, iy + s * 0.7f, p);
                    c.drawLine(ix - s * 0.3f, iy + s * 0.7f, ix + s, iy - s * 0.7f, p);
                    break;
                }
                case BTN_START: { // play
                    Path t = new Path();
                    t.moveTo(ix - s * 0.6f, iy - s);
                    t.lineTo(ix + s * 0.95f, iy);
                    t.lineTo(ix - s * 0.6f, iy + s);
                    t.close();
                    c.drawPath(t, solid);
                    break;
                }
                case BTN_STOP:
                    c.drawRoundRect(new RectF(ix - s * 0.85f, iy - s * 0.85f, ix + s * 0.85f, iy + s * 0.85f), dp(2), dp(2), solid);
                    break;
                case BTN_CLEAR: // cross
                    c.drawLine(ix - s * 0.8f, iy - s * 0.8f, ix + s * 0.8f, iy + s * 0.8f, stroke);
                    c.drawLine(ix + s * 0.8f, iy - s * 0.8f, ix - s * 0.8f, iy + s * 0.8f, stroke);
                    break;
                case BTN_EXIT: { // power symbol
                    c.drawArc(new RectF(ix - s, iy - s, ix + s, iy + s), -55, 290, false, stroke);
                    c.drawLine(ix, iy - s * 1.15f, ix, iy - s * 0.1f, stroke);
                    break;
                }
            }
            c.drawText(LABELS[type], w / 2f, h * 0.84f, text);
        }
    }

    /** Full-screen capture layer shown during Select: taps mark tiles instead of opening them. */
    private final class SelectView extends View {
        private final Paint tint = new Paint();
        private final Paint border = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markFill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint markStroke = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint checkPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint pillText = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int[] loc = new int[2];
        private final int slop = ViewConfiguration.get(OverlayService.this).getScaledTouchSlop();
        private float downX, downY;
        private long downT;

        SelectView(Context c) {
            super(c);
            tint.setColor(0x18000000);
            border.setStyle(Paint.Style.STROKE);
            border.setStrokeWidth(dp(4));
            border.setColor(0xCC2ECC71);
            markFill.setColor(0x552ECC71);
            markStroke.setStyle(Paint.Style.STROKE);
            markStroke.setStrokeWidth(dp(3));
            markStroke.setColor(0xFF2ECC71);
            checkPaint.setStyle(Paint.Style.STROKE);
            checkPaint.setStrokeWidth(dp(4));
            checkPaint.setStrokeCap(Paint.Cap.ROUND);
            checkPaint.setStrokeJoin(Paint.Join.ROUND);
            checkPaint.setColor(Color.WHITE);
            pill.setColor(0xDD101418);
            pillText.setColor(Color.WHITE);
            pillText.setTextAlign(Paint.Align.CENTER);
            pillText.setTextSize(dp(12));
            pillText.setFakeBoldText(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            getLocationOnScreen(loc);
            c.drawRect(0, 0, getWidth(), getHeight(), tint);
            c.drawRect(dp(2), dp(2), getWidth() - dp(2), getHeight() - dp(2), border);

            TikTokAccessibilityService svc = TikTokAccessibilityService.getInstance();
            if (svc != null) {
                List<Tile> tiles = svc.getQueue();
                int n = 0;
                for (Tile t : tiles) {
                    n++;
                    float px = t.x - loc[0], py = t.y - loc[1];
                    if (t.rect != null) {
                        RectF r = new RectF(t.rect.left - loc[0] + dp(3), t.rect.top - loc[1] + dp(3),
                                t.rect.right - loc[0] - dp(3), t.rect.bottom - loc[1] - dp(3));
                        c.drawRoundRect(r, dp(6), dp(6), markFill);
                        c.drawRoundRect(r, dp(6), dp(6), markStroke);
                    }
                    float rad = dp(18);
                    c.drawCircle(px, py, rad, markStroke);
                    Paint solidGreen = new Paint(Paint.ANTI_ALIAS_FLAG);
                    solidGreen.setColor(0xFF2ECC71);
                    c.drawCircle(px, py, rad - dp(1), solidGreen);
                    c.drawLine(px - rad * 0.4f, py, px - rad * 0.1f, py + rad * 0.35f, checkPaint);
                    c.drawLine(px - rad * 0.1f, py + rad * 0.35f, px + rad * 0.45f, py - rad * 0.35f, checkPaint);
                }
            }
            String msg = "SELECT MODE - tap videos to mark them";
            float tw = pillText.measureText(msg) + dp(28);
            float top = dp(40);
            RectF pr = new RectF(getWidth() / 2f - tw / 2, top, getWidth() / 2f + tw / 2, top + dp(30));
            c.drawRoundRect(pr, dp(15), dp(15), pill);
            c.drawText(msg, getWidth() / 2f, top + dp(20), pillText);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = e.getRawX();
                    downY = e.getRawY();
                    downT = System.currentTimeMillis();
                    return true;
                case MotionEvent.ACTION_UP: {
                    float dx = e.getRawX() - downX, dy = e.getRawY() - downY;
                    long dt = System.currentTimeMillis() - downT;
                    if (Math.hypot(dx, dy) <= slop * 2f) {
                        onSelectTap(downX, downY);
                    } else {
                        onSelectSwipe(downX, downY, e.getRawX(), e.getRawY(), dt);
                    }
                    return true;
                }
                default:
                    return true;
            }
        }
    }
}
