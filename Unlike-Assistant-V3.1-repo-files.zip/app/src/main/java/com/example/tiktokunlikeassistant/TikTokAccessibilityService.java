package com.example.tiktokunlikeassistant;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.WindowManager;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public final class TikTokAccessibilityService extends AccessibilityService {

    public interface Listener {
        void onStateChanged();
    }

    private static volatile TikTokAccessibilityService instance;
    private static volatile Listener listener;

    public static TikTokAccessibilityService getInstance() {
        return instance;
    }

    public static void setListener(Listener l) {
        listener = l;
    }

    // results of processing one tile
    private static final int R_OK = 1;
    private static final int R_ALREADY = 2;
    private static final int R_UNVERIFIED = 3;
    private static final int R_FAIL = 0;
    private static final int R_NOT_OPENED = -1;
    private static final int R_CANCEL = -2;

    private final CopyOnWriteArrayList<Tile> queue = new CopyOnWriteArrayList<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private volatile boolean running;
    private volatile boolean cancel;
    private volatile Thread worker;

    /** What we found on the full-screen video page. */
    private static final class Rail {
        boolean inVideo;
        AccessibilityNodeInfo likeNode; // may be null
        Rect likeRect;                  // never null when inVideo
    }

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onServiceConnected() {
        instance = this;
        notifyState();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Selection is done through our own overlay now, nothing to observe here.
    }

    @Override
    public void onInterrupt() {
        stopQueue(false);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        stopQueue(false);
        instance = null;
        notifyState();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        stopQueue(false);
        instance = null;
        super.onDestroy();
    }

    // ------------------------------------------------------------------ public api (used by the overlay)

    public boolean isRunning() {
        return running;
    }

    public int queueSize() {
        return queue.size();
    }

    public List<Tile> getQueue() {
        return new ArrayList<>(queue);
    }

    public void clearQueue() {
        stopQueue(false);
        queue.clear();
        notifyState();
    }

    /** Adds the tile under (x,y) to the queue, or removes it when it is already queued. Returns true when added. */
    public boolean toggleTile(int x, int y) {
        Rect r = findTileRect(x, y);
        int cx = r != null ? r.centerX() : x;
        int cy = r != null ? r.centerY() : y;
        int near = Math.max(40, (int) (getResources().getDisplayMetrics().density * 28));
        for (Tile t : queue) {
            boolean sameTile = (t.rect != null && t.rect.contains(x, y))
                    || Math.hypot(t.x - x, t.y - y) < near;
            if (sameTile) {
                queue.remove(t);
                notifyState();
                return false;
            }
        }
        queue.add(new Tile(cx, cy, r));
        notifyState();
        return true;
    }

    public void startQueue() {
        if (running) {
            toast("Already running");
            return;
        }
        if (queue.isEmpty()) {
            toast("Queue is empty - use SELECT first");
            return;
        }
        final ArrayList<Tile> list = new ArrayList<>(queue);
        // bottom row first, right to left: removing a video never shifts the ones still waiting
        Collections.sort(list, new Comparator<Tile>() {
            @Override
            public int compare(Tile a, Tile b) {
                if (a.y != b.y) return Integer.compare(b.y, a.y);
                return Integer.compare(b.x, a.x);
            }
        });
        cancel = false;
        running = true;
        notifyState();
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                runQueue(list);
            }
        }, "unlike-worker");
        worker = t;
        t.start();
    }

    public void stopQueue(boolean showToast) {
        boolean was = running;
        cancel = true;
        running = false;
        Thread w = worker;
        if (w != null) w.interrupt();
        OverlayService.setPassThrough(false);
        if (showToast && was) toast("Stopped");
        notifyState();
    }

    /** Replays a swipe the user made on our selection overlay so the grid underneath scrolls. */
    public void swipe(float x0, float y0, float x1, float y1, long duration, final Runnable done) {
        Path p = new Path();
        p.moveTo(x0, y0);
        p.lineTo(x1, y1);
        long d = Math.max(80, Math.min(600, duration));
        boolean sent = false;
        try {
            sent = dispatchGesture(new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, d)).build(),
                    new GestureResultCallback() {
                        @Override
                        public void onCompleted(GestureDescription g) {
                            if (done != null) done.run();
                        }

                        @Override
                        public void onCancelled(GestureDescription g) {
                            if (done != null) done.run();
                        }
                    }, null);
        } catch (Throwable ignored) {
        }
        if (!sent && done != null) done.run();
    }

    // ------------------------------------------------------------------ the worker

    private void runQueue(List<Tile> list) {
        int ok = 0, already = 0, fail = 0, notOpened = 0;
        try {
            for (int i = 0; i < list.size() && !cancel; i++) {
                Tile t = list.get(i);
                toast("Unliking " + (i + 1) + " / " + list.size());
                int res = processTile(t);
                if (res == R_CANCEL) break;
                if (res == R_OK || res == R_UNVERIFIED) ok++;
                else if (res == R_ALREADY) already++;
                else if (res == R_NOT_OPENED) notOpened++;
                else fail++;
                queue.remove(t);
                notifyState();
                if (!nap(500)) break;
            }
        } catch (Throwable ignored) {
        }
        boolean wasCancelled = cancel;
        running = false;
        OverlayService.setPassThrough(false);
        notifyState();
        if (!wasCancelled) {
            StringBuilder sb = new StringBuilder("Finished: ").append(ok).append(" unliked");
            if (already > 0) sb.append(", ").append(already).append(" were already unliked");
            if (fail > 0) sb.append(", ").append(fail).append(" failed");
            if (notOpened > 0) sb.append(", ").append(notOpened).append(" didn't open");
            toast(sb.toString());
        }
    }

    private int processTile(Tile t) {
        // 1. open the video
        if (!tap(t.x, t.y)) return R_FAIL;

        // 2. wait until the full-screen video page is really there
        if (!nap(1000)) return R_CANCEL;
        Rail rail = null;
        long end = System.currentTimeMillis() + 4500;
        while (!cancel && System.currentTimeMillis() < end) {
            rail = readRail();
            if (rail != null && rail.inVideo) break;
            rail = null;
            if (!nap(350)) return R_CANCEL;
        }
        if (cancel) return R_CANCEL;
        if (rail == null) {
            // we are still on the grid: do NOT press back, that would leave the profile
            return R_NOT_OPENED;
        }
        if (!nap(450)) return R_CANCEL;
        // layout may have moved a bit while the page was animating in
        Rail fresh = readRail();
        if (fresh != null && fresh.inVideo) rail = fresh;

        // 3. unlike
        int res = ensureUnliked(rail);
        if (res == R_CANCEL) return res;

        // 4. close the video
        leaveVideo();
        return res;
    }

    private int ensureUnliked(Rail rail) {
        Rect r = rail.likeRect;
        Boolean liked = heartIsRed(r);
        if (liked != null && !liked) return R_ALREADY; // clicking would LIKE it again

        // attempt 1: accessibility click on the heart (falls back to a real tap)
        if (rail.likeNode != null) {
            if (!clickNode(rail.likeNode)) tapRect(r);
        } else {
            tapRect(r);
        }
        if (!nap(900)) return R_CANCEL;
        if (liked == null) return R_UNVERIFIED; // no screenshot support: can't verify

        Boolean after = heartIsRed(r);
        if (after != null && !after) return R_OK;
        if (!nap(600)) return R_CANCEL; // animation lag? look again before touching it twice
        after = heartIsRed(r);
        if (after != null && !after) return R_OK;

        // attempt 2: a real finger tap on the heart
        tapRect(r);
        if (!nap(900)) return R_CANCEL;
        after = heartIsRed(r);
        if (after == null || !after) return R_OK;
        return R_FAIL;
    }

    private void leaveVideo() {
        for (int i = 0; i < 3 && !cancel; i++) {
            performGlobalAction(GLOBAL_ACTION_BACK);
            if (!nap(1000)) return;
            Rail r = readRail();
            if (r == null || !r.inVideo) return;
        }
    }

    // ------------------------------------------------------------------ reading TikTok's screen

    private int[] screen() {
        DisplayMetrics dm = new DisplayMetrics();
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.getDefaultDisplay().getRealMetrics(dm);
        return new int[]{dm.widthPixels, dm.heightPixels};
    }

    /** Roots of every app window that is not ours. Never returns our own overlay. */
    private List<AccessibilityNodeInfo> appRoots() {
        List<AccessibilityNodeInfo> out = new ArrayList<>();
        String me = getPackageName();
        try {
            List<AccessibilityWindowInfo> ws = getWindows();
            if (ws != null) {
                for (AccessibilityWindowInfo w : ws) {
                    if (w.getType() != AccessibilityWindowInfo.TYPE_APPLICATION) continue;
                    AccessibilityNodeInfo r = w.getRoot();
                    if (r == null) continue;
                    CharSequence pkg = r.getPackageName();
                    if (pkg != null && me.contentEquals(pkg)) continue;
                    out.add(r);
                }
            }
        } catch (Throwable ignored) {
        }
        if (out.isEmpty()) {
            try {
                AccessibilityNodeInfo r = getRootInActiveWindow();
                if (r != null) {
                    CharSequence pkg = r.getPackageName();
                    if (pkg == null || !me.contentEquals(pkg)) out.add(r);
                }
            } catch (Throwable ignored) {
            }
        }
        return out;
    }

    private static String lower(CharSequence a, CharSequence b) {
        StringBuilder sb = new StringBuilder();
        if (a != null) sb.append(a);
        sb.append(' ');
        if (b != null) sb.append(b);
        return sb.toString().toLowerCase(Locale.ROOT);
    }

    private Rect findTileRect(int x, int y) {
        int[] s = screen();
        int w = s[0], h = s[1];
        Rect[] best = new Rect[1];
        int[] counter = new int[1];
        for (AccessibilityNodeInfo root : appRoots()) {
            scanTile(root, x, y, w, h, best, counter, 0);
        }
        return best[0];
    }

    private void scanTile(AccessibilityNodeInfo n, int x, int y, int w, int h, Rect[] best, int[] counter, int depth) {
        if (n == null || depth > 45 || counter[0]++ > 4000) return;
        Rect b = new Rect();
        n.getBoundsInScreen(b);
        if (n.isVisibleToUser() && b.contains(x, y)) {
            int bw = b.width(), bh = b.height();
            if (bw >= w / 6 && bw <= w * 0.6 && bh >= h / 14 && bh <= h * 0.45) {
                if (best[0] == null || (long) bw * bh < (long) best[0].width() * best[0].height()) {
                    best[0] = b;
                }
            }
        }
        int c = n.getChildCount();
        for (int i = 0; i < c; i++) {
            scanTile(n.getChild(i), x, y, w, h, best, counter, depth + 1);
        }
    }

    /**
     * Looks for the full-screen video page: the right-hand button rail (heart / comments / save / share)
     * or tell-tale texts of that page. Returns null when we are not on it.
     */
    private Rail readRail() {
        int[] s = screen();
        int w = s[0], h = s[1];
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        List<Rect> rects = new ArrayList<>();
        AccessibilityNodeInfo[] likeByLabel = new AccessibilityNodeInfo[1];
        boolean[] marker = new boolean[1];
        int[] counter = new int[1];
        for (AccessibilityNodeInfo root : appRoots()) {
            collectRail(root, w, h, nodes, rects, likeByLabel, marker, counter, 0);
        }
        // sort rail items top -> bottom
        List<Integer> idx = new ArrayList<>();
        for (int i = 0; i < rects.size(); i++) idx.add(i);
        final List<Rect> rr = rects;
        Collections.sort(idx, new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                return Integer.compare(rr.get(a).centerY(), rr.get(b).centerY());
            }
        });
        List<Rect> sr = new ArrayList<>();
        List<AccessibilityNodeInfo> sn = new ArrayList<>();
        for (int i : idx) {
            sr.add(rects.get(i));
            sn.add(nodes.get(i));
        }

        boolean inVideo = sr.size() >= 3 || marker[0];
        if (!inVideo) return null;

        Rail rail = new Rail();
        rail.inVideo = true;
        if (likeByLabel[0] != null) {
            Rect b = new Rect();
            likeByLabel[0].getBoundsInScreen(b);
            rail.likeNode = likeByLabel[0];
            rail.likeRect = b;
        } else if (sr.size() >= 4) {
            // [avatar] heart, comments, save, share  -> heart is 4th from the bottom
            rail.likeRect = sr.get(sr.size() - 4);
            rail.likeNode = sn.get(sr.size() - 4);
        } else if (sr.size() == 3) {
            rail.likeRect = sr.get(0);
            rail.likeNode = sn.get(0);
        } else {
            int cx = (int) (w * 0.92), cy = (int) (h * 0.59), r = (int) (w * 0.05);
            rail.likeRect = new Rect(cx - r, cy - r, cx + r, cy + r);
        }
        return rail;
    }

    private void collectRail(AccessibilityNodeInfo n, int w, int h, List<AccessibilityNodeInfo> nodes, List<Rect> rects,
                             AccessibilityNodeInfo[] likeByLabel, boolean[] marker, int[] counter, int depth) {
        if (n == null || depth > 45 || counter[0]++ > 4000) return;
        String label = lower(n.getContentDescription(), n.getText());
        if (label.contains("find related content") || label.contains("add comment")) marker[0] = true;

        if (n.isVisibleToUser()) {
            Rect b = new Rect();
            n.getBoundsInScreen(b);
            boolean inRail = b.width() > 0 && b.height() > 0
                    && b.width() <= w * 0.22 && b.height() <= h * 0.2
                    && b.centerX() >= w * 0.78
                    && b.centerY() >= h * 0.28 && b.centerY() <= h * 0.92;
            if (inRail) {
                if (n.isClickable()) {
                    boolean dup = false;
                    for (Rect e : rects) {
                        if (Math.abs(e.centerY() - b.centerY()) < h * 0.03) {
                            dup = true;
                            break;
                        }
                    }
                    if (!dup) {
                        nodes.add(n);
                        rects.add(b);
                    }
                }
                if (likeByLabel[0] == null && looksLikeLike(label)) likeByLabel[0] = n;
            }
        }
        int c = n.getChildCount();
        for (int i = 0; i < c; i++) {
            collectRail(n.getChild(i), w, h, nodes, rects, likeByLabel, marker, counter, depth + 1);
        }
    }

    private static boolean looksLikeLike(String s) {
        if (s.contains("comment") || s.contains("share") || s.contains("save") || s.contains("favorite")
                || s.contains("favourite") || s.contains("bookmark") || s.contains("follow")
                || s.contains("kommentar") || s.contains("teilen") || s.contains("speichern")) return false;
        return s.contains("like") || s.contains("gefällt") || s.contains("me gusta")
                || s.contains("j'aime") || s.contains("mi piace");
    }

    // ------------------------------------------------------------------ touching things

    private boolean clickNode(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo cur = node;
        for (int i = 0; i < 4 && cur != null; i++) {
            try {
                if (cur.isClickable() && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
            } catch (Throwable ignored) {
            }
            cur = cur.getParent();
        }
        return false;
    }

    private void tapRect(Rect r) {
        tap(r.centerX(), r.centerY());
    }

    /** Real finger tap. Our own overlay is made touch-transparent first so it can never swallow the tap. */
    private boolean tap(int x, int y) {
        OverlayService.setPassThrough(true);
        try {
            if (!nap(150)) return false;
            Path p = new Path();
            p.moveTo(x, y);
            final boolean[] res = new boolean[1];
            final CountDownLatch latch = new CountDownLatch(1);
            boolean sent = dispatchGesture(new GestureDescription.Builder()
                    .addStroke(new GestureDescription.StrokeDescription(p, 0, 70)).build(),
                    new GestureResultCallback() {
                        @Override
                        public void onCompleted(GestureDescription g) {
                            res[0] = true;
                            latch.countDown();
                        }

                        @Override
                        public void onCancelled(GestureDescription g) {
                            latch.countDown();
                        }
                    }, null);
            if (!sent) return false;
            try {
                latch.await(3, TimeUnit.SECONDS);
            } catch (InterruptedException e) {
                return false;
            }
            return res[0];
        } finally {
            OverlayService.setPassThrough(false);
        }
    }

    // ------------------------------------------------------------------ screenshot based "is the heart red?" check

    /** true = red (liked), false = not red, null = could not tell. */
    private Boolean heartIsRed(Rect r) {
        if (Build.VERSION.SDK_INT < 30) return null;
        Bitmap bmp = null;
        for (int attempt = 0; attempt < 3 && bmp == null && !cancel; attempt++) {
            bmp = screenshot();
            if (bmp == null && !nap(450)) return null;
        }
        if (bmp == null) return null;
        try {
            int[] s = screen();
            float sx = bmp.getWidth() / (float) s[0];
            float sy = bmp.getHeight() / (float) s[1];
            int half = Math.max(8, (int) (s[0] * 0.03f));
            int cx = r.centerX(), cy = r.centerY();
            int x0 = Math.max(0, (int) ((cx - half) * sx)), x1 = Math.min(bmp.getWidth() - 1, (int) ((cx + half) * sx));
            int y0 = Math.max(0, (int) ((cy - half) * sy)), y1 = Math.min(bmp.getHeight() - 1, (int) ((cy + half) * sy));
            if (x1 <= x0 || y1 <= y0) return null;
            int total = 0, red = 0;
            for (int y = y0; y <= y1; y += 2) {
                for (int x = x0; x <= x1; x += 2) {
                    int c = bmp.getPixel(x, y);
                    int rr = (c >> 16) & 0xFF, gg = (c >> 8) & 0xFF, bb = c & 0xFF;
                    total++;
                    if (rr > 190 && gg < 120 && bb < 140 && rr - gg > 100) red++;
                }
            }
            return total > 0 && red >= total * 0.15;
        } finally {
            bmp.recycle();
        }
    }

    private Bitmap screenshot() {
        final Bitmap[] out = new Bitmap[1];
        final CountDownLatch latch = new CountDownLatch(1);
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                @Override
                public void onSuccess(ScreenshotResult result) {
                    try {
                        Bitmap hw = Bitmap.wrapHardwareBuffer(result.getHardwareBuffer(), result.getColorSpace());
                        if (hw != null) {
                            out[0] = hw.copy(Bitmap.Config.ARGB_8888, false);
                            hw.recycle();
                        }
                        result.getHardwareBuffer().close();
                    } catch (Throwable ignored) {
                    }
                    latch.countDown();
                }

                @Override
                public void onFailure(int errorCode) {
                    latch.countDown();
                }
            });
            latch.await(3, TimeUnit.SECONDS);
        } catch (Throwable t) {
            return null;
        }
        return out[0];
    }

    // ------------------------------------------------------------------ helpers

    /** Sleep that returns false as soon as the run is cancelled. */
    private boolean nap(long ms) {
        long end = System.currentTimeMillis() + ms;
        while (System.currentTimeMillis() < end) {
            if (cancel) return false;
            try {
                Thread.sleep(40);
            } catch (InterruptedException e) {
                return false;
            }
        }
        return !cancel;
    }

    private void toast(final String msg) {
        main.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(TikTokAccessibilityService.this, msg, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void notifyState() {
        main.post(new Runnable() {
            @Override
            public void run() {
                Listener l = listener;
                if (l != null) l.onStateChanged();
            }
        });
    }
}
