package com.example.tiktokunlikeassistant

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private val prefs by lazy { getSharedPreferences("selection", Context.MODE_PRIVATE) }

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showPanel()
    }

    private fun startAsForeground() {
        val channelId = "unlike_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(channelId, "Unlike assistant", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
        val notification = Notification.Builder(this, channelId)
            .setContentTitle("TikTok Unlike Assistant")
            .setContentText("Floating controls are active")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .build()
        startForeground(7, notification)
    }

    private fun showPanel() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 14, 18, 14)
            setBackgroundColor(Color.argb(238, 28, 28, 32))
        }
        val title = TextView(this).apply { text = "Unlike Assistant"; setTextColor(Color.WHITE); textSize = 16f }
        box.addView(title)
        val status = TextView(this).apply { text = "Scan the visible liked-video grid."; setTextColor(Color.WHITE) }
        box.addView(status)
        fun button(label: String, fn: () -> Unit) {
            box.addView(Button(this).apply { text = label; setOnClickListener { fn() } })
        }
        button("Scan visible grid") {
            TikTokAccessibilityService.instance?.scanGrid()
            status.text = "Scan requested. Reopen panel or press Scan again after TikTok loads."
        }
        button("Show / select detected items") {
            val items = TikTokAccessibilityService.instance?.lastGridItems.orEmpty()
            if (items.isEmpty()) {
                status.text = "No grid items detected. Make sure TikTok's Liked videos grid is open."
            } else {
                val labels = items.mapIndexed { i, item -> "${i + 1}. ${item.label}" }.toTypedArray()
                val checked = BooleanArray(items.size) { i -> prefs.getBoolean("item_$i", false) }
                AlertDialog.Builder(this)
                    .setTitle("Select visible videos")
                    .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                        prefs.edit().putBoolean("item_$which", isChecked).apply()
                    }
                    .setPositiveButton("Save selection") { _, _ ->
                        val selected = items.indices.filter { prefs.getBoolean("item_$it", false) }
                        prefs.edit().putString("selected_indices", selected.joinToString(",")).apply()
                        status.text = "${selected.size} visible item(s) selected."
                    }
                    .setNegativeButton("Cancel", null).show()
            }
        }
        button("START automatic unlike") {
            val selected = prefs.getString("selected_indices", "").orEmpty()
            if (selected.isBlank()) status.text = "Select at least one item first."
            else {
                status.text = "Automation requested. Keep TikTok on the liked grid."
                TikTokAccessibilityService.instance?.startUnliking(selected)
                    ?: run { status.text = "Enable the accessibility service first." }
            }
        }
        button("STOP") {
            TikTokAccessibilityService.instance?.stopUnliking()
            status.text = "Stopped."
        }
        button("Close panel") { stopSelf() }
        val params = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.82f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 140 }
        panel = box
        wm.addView(box, params)
    }

    override fun onDestroy() {
        panel?.let { wm.removeView(it) }
        panel = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
