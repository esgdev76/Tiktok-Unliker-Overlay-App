package com.example.tiktokunlikeassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.Locale

data class GridItem(val label: String, val bounds: Rect)

class TikTokAccessibilityService : AccessibilityService() {
    companion object { var instance: TikTokAccessibilityService? = null }
    var lastGridItems: List<GridItem> = emptyList()
        private set
    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var selectedPositions: List<Int> = emptyList()
    private var cursor = 0

    override fun onServiceConnected() {
        instance = this
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* UI is inspected on explicit user action. */ }
    override fun onInterrupt() { stopUnliking() }

    fun scanGrid() {
        val root = rootInActiveWindow ?: return
        val found = mutableListOf<GridItem>()
        collectGridCandidates(root, found)
        lastGridItems = found.distinctBy { "${it.bounds.left},${it.bounds.top},${it.bounds.right},${it.bounds.bottom}" }
            .sortedWith(compareBy<GridItem> { it.bounds.top }.thenBy { it.bounds.left })
            .take(60)
        Toast.makeText(this, "Detected ${lastGridItems.size} possible grid tiles", Toast.LENGTH_SHORT).show()
    }

    private fun collectGridCandidates(node: AccessibilityNodeInfo, out: MutableList<GridItem>) {
        val r = Rect()
        node.getBoundsInScreen(r)
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val plausible = r.width() > screenW / 5 && r.height() > screenH / 12 &&
            r.width() < screenW * 0.8 && r.height() < screenH * 0.65 &&
            r.top >= 0 && r.bottom <= screenH
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val txt = node.text?.toString()?.trim().orEmpty()
        val label = (desc.ifBlank { txt }).ifBlank { "Video tile at ${r.left},${r.top}" }
        if (plausible && node.isClickable && r.width() > 0 && r.height() > 0) out.add(GridItem(label.take(90), Rect(r)))
        for (i in 0 until node.childCount) node.getChild(i)?.let { child ->
            collectGridCandidates(child, out)
            child.recycle()
        }
    }

    fun startUnliking(csv: String) {
        if (running) return
        scanGrid()
        selectedPositions = csv.split(",").mapNotNull { it.toIntOrNull() }.filter { it in lastGridItems.indices }.sortedDescending()
        if (selectedPositions.isEmpty()) {
            Toast.makeText(this, "No valid selected tiles. Scan and select again.", Toast.LENGTH_LONG).show()
            return
        }
        cursor = 0
        running = true
        Toast.makeText(this, "Starting. Keep TikTok visible; use STOP to cancel.", Toast.LENGTH_LONG).show()
        processNext()
    }

    private fun processNext() {
        if (!running) return
        if (cursor >= selectedPositions.size) {
            running = false
            Toast.makeText(this, "Queue finished.", Toast.LENGTH_LONG).show()
            return
        }
        val root = rootInActiveWindow
        if (root == null) { pauseAndRetry(); return }
        val currentIndex = selectedPositions[cursor]
        val item = lastGridItems.getOrNull(currentIndex)
        if (item == null) { cursor++; processNext(); return }
        val centerX = item.bounds.centerX()
        val centerY = item.bounds.centerY()
        val path = android.graphics.Path().apply { moveTo(centerX.toFloat(), centerY.toFloat()) }
        val gesture = android.accessibilityservice.GestureDescription.Builder()
            .addStroke(android.accessibilityservice.GestureDescription.StrokeDescription(path, 0, 80)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: android.accessibilityservice.GestureDescription?) {
                handler.postDelayed({ findAndClickUnlikeOrBack() }, 1400)
            }
            override fun onCancelled(gestureDescription: android.accessibilityservice.GestureDescription?) { pauseAndRetry() }
        }, null)
    }

    private fun findAndClickUnlikeOrBack() {
        if (!running) return
        val root = rootInActiveWindow
        if (root == null) { pauseAndRetry(); return }
        val unlike = findUnlikeButton(root)
        if (unlike != null) {
            unlike.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            unlike.recycle()
            handler.postDelayed({
                performGlobalAction(GLOBAL_ACTION_BACK)
                handler.postDelayed({
                    cursor++
                    scanGrid()
                    processNext()
                }, 1200)
            }, 700)
        } else {
            Toast.makeText(this, "Like control not recognized; skipped this item.", Toast.LENGTH_SHORT).show()
            performGlobalAction(GLOBAL_ACTION_BACK)
            handler.postDelayed({ cursor++; scanGrid(); processNext() }, 1200)
        }
    }

    private fun findUnlikeButton(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val description = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val text = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val combined = "$description $text"
        val positive = listOf("unlike", "remove from liked", "remove like", "liked")
        if (node.isClickable && positive.any { combined.contains(it) }) return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findUnlikeButton(child)
            child.recycle()
            if (result != null) return result
        }
        return null
    }

    private fun pauseAndRetry() {
        if (!running) return
        handler.postDelayed({ processNext() }, 1200)
    }

    fun stopUnliking() {
        running = false
        handler.removeCallbacksAndMessages(null)
        Toast.makeText(this, "Automation stopped.", Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        stopUnliking()
        instance = null
        super.onDestroy()
    }
}
