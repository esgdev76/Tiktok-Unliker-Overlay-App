# TikTok Unlike Assistant (experimental Android project)

This is an experimental Android AccessibilityService + floating overlay project. It is **not an official TikTok app or integration**. TikTok does not provide a public API for selecting and bulk-unliking videos, so this project relies on UI automation and may stop working when TikTok changes its interface.

## What is included
- Kotlin Android app source
- Floating overlay controls (scan, select, start, stop)
- Accessibility service that inspects visible clickable UI nodes and attempts to click a recognized Unlike/Liked control
- GitHub Actions workflow that builds a debug APK

## Important limitations
- The grid scanner uses accessibility node labels and screen bounds. TikTok may expose thumbnails without useful labels, or expose nested clickable nodes. Detection can be incomplete or inaccurate.
- The selection is a **best-effort snapshot of visible grid tiles**, not a permanent video ID list. TikTok can reorder/reflow the grid after an unlike. Test with one expendable like first.
- The automation only attempts to click a button whose accessibility label contains `Unlike`, `Remove from liked`, `Remove like`, or `Liked`. If TikTok labels the control differently, it skips the item rather than guessing.
- UI timing, ads, dialogs, login prompts, network delays, and app updates can interrupt the sequence. Keep the phone unlocked and TikTok in the foreground.
- This project has not been tested against every TikTok version/device. Treat it as a starting point, not a guaranteed working bulk-unlike tool.

## Build APK with GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP to its root.
2. Open **Actions**. The workflow named **Build Android APK** runs on push to `main`, or choose **Run workflow**.
3. Open the completed workflow run and download the `tiktok-unlike-assistant-debug-apk` artifact.
4. Extract the artifact ZIP to get `app-debug.apk`. Install it on your Android device (you may need to allow installation from that source).

The workflow uses Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and JDK 17. It builds a debug APK, not a Play Store release.

## Set up on Android
1. Install and open the app.
2. Tap **Enable Accessibility Service** and enable TikTok Unlike Assistant in Android Accessibility settings.
3. Tap **Grant Overlay Permission** and allow display over other apps.
4. Tap **Start Floating Panel**.
5. Open TikTok, go to Profile → Liked videos, and keep the grid visible.
6. In the floating panel, tap **Scan visible grid**, then **Show / select detected items**.
7. Select a small number of entries and save. Tap **START automatic unlike**.
8. Watch the first operation. Tap **STOP** immediately if it targets the wrong tile or control.

## Privacy
The app contains no analytics, ads, account login, network client, or credential collection. Accessibility access is powerful: Android will show the service permission disclosure. Review the source before enabling it. Do not use it on an account or content you do not control.

## Troubleshooting
- If no tiles appear, TikTok may not expose clickable tile nodes. Try a different TikTok build or inspect the UI with an accessibility inspector.
- If no Unlike control is recognized, the service will skip the item. Do not broaden the matching rules without verifying the exact accessibility label on your device.
- If the panel disappears, reopen the app and start it again.
