package com.example.tiktokunlikeassistant

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Typeface

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        showBubble()
    }

    private fun overlayParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    )

    private fun showBubble() {
        if (bubble != null) return
        val b = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFF17171D.toInt())
                setStroke(dp(2), 0xFFFE2C55.toInt())
            }
            clipToOutline = true
            elevation = 12f
            contentDescription = "Open Unlike Assistant controls"
        }
        val p = overlayParams(dp(58), dp(58)).apply { gravity = Gravity.TOP or Gravity.START; x = dp(18); y = dp(180) }
        bubbleParams = p
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var dragged = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = p.x; startY = p.y; dragged = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (kotlin.math.abs(dx) > 5 || kotlin.math.abs(dy) > 5) dragged = true
                    p.x = startX + dx; p.y = startY + dy; wm.updateViewLayout(b, p); true
                }
                MotionEvent.ACTION_UP -> {
                    if (!dragged) togglePanel()
                    true
                }
                else -> true
            }
        }
        bubble = b
        wm.addView(b, p)
    }

    private fun togglePanel() {
        if (panel != null) { wm.removeView(panel); panel = null; return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setBackgroundColor(0xF01A1A22.toInt())
        }
        val heading = TextView(this).apply {
            text = "Unlike Assistant"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val status = TextView(this).apply {
            text = "Queue: ${TikTokAccessibilityService.instance?.queueSize() ?: 0}"
            textSize = 13f; setTextColor(0xFFD5D5DE.toInt()); setPadding(0, dp(6), 0, dp(8))
        }
        fun addButton(label: String, action: () -> Unit) {
            box.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        addButton("SELECT") {
            val svc = TikTokAccessibilityService.instance
            if (svc == null) status.text = "Enable Accessibility first."
            else { svc.setSelectionMode(true); status.text = "Selection ON: tap the desired liked-video tiles in TikTok." }
        }
        addButton("Done selecting") {
            TikTokAccessibilityService.instance?.setSelectionMode(false)
            status.text = "Selection paused. Queue: ${TikTokAccessibilityService.instance?.queueSize() ?: 0}"
        }
        addButton("START automatic unlike") {
            val svc = TikTokAccessibilityService.instance
            if (svc == null) status.text = "Enable Accessibility first."
            else { svc.startQueue(); status.text = "Started. Keep TikTok visible; watch the first item." }
        }
        addButton("STOP") { TikTokAccessibilityService.instance?.stopQueue(); status.text = "Stopped." }
        addButton("Clear queue") { TikTokAccessibilityService.instance?.clearQueue(); status.text = "Queue cleared." }
        addButton("Hide panel") { togglePanel() }
        box.addView(status)
        val p = overlayParams(dp(260), WindowManager.LayoutParams.WRAP_CONTENT).apply {
            gravity = Gravity.TOP or Gravity.START
            val bp = bubbleParams
            x = (bp?.x ?: dp(18)); y = (bp?.y ?: dp(180)) + dp(64)
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        panel = box
        wm.addView(box, p)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onDestroy() {
        panel?.let { wm.removeView(it) }; panel = null
        bubble?.let { wm.removeView(it) }; bubble = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
