package com.example.tiktokunlikeassistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(0xFF101014.toInt())
        }
        root.addView(TextView(this).apply {
            text = "Unlike Assistant"
            textSize = 28f
            setTextColor(0xFFFFFFFF.toInt())
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        })
        root.addView(TextView(this).apply {
            text = "Floating controls • Select • Queue • Start"
            textSize = 14f
            setTextColor(0xFFB8B8C2.toInt())
            setPadding(0, 8, 0, 24)
        })
        fun add(label: String, action: () -> Unit) {
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })
        }
        add("1. Enable Accessibility") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        add("2. Allow floating icon") {
            if (!Settings.canDrawOverlays(this))
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        add("3. Start floating icon") {
            if (Settings.canDrawOverlays(this)) startService(Intent(this, OverlayService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        root.addView(TextView(this).apply {
            text = "How to use: Open TikTok → Profile → Liked videos. Tap the floating icon, choose Select, then tap the liked-video tiles you want to queue. Start only after checking the queue. Automation is experimental and may not recognize TikTok's current controls."
            textSize = 14f
            setTextColor(0xFFD6D6DE.toInt())
            setPadding(0, 22, 0, 0)
        })
        setContentView(root)
    }
}
