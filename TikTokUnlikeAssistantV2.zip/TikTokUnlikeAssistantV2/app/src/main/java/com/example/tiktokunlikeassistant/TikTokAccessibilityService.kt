package com.example.tiktokunlikeassistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Toast
import java.util.concurrent.CopyOnWriteArrayList
import java.util.Locale

data class QueuedTile(val x: Int, val y: Int, val label: String)

class TikTokAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: TikTokAccessibilityService? = null }
    private val queue = CopyOnWriteArrayList<QueuedTile>()
    private val handler = Handler(Looper.getMainLooper())
    private var selecting = false
    private var running = false
    private var index = 0

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!selecting || event?.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return
        val node = event.source ?: return
        try {
            val bounds = Rect()
            node.getBoundsInScreen(bounds)
            val root = rootInActiveWindow
            val screenH = resources.displayMetrics.heightPixels
            val screenW = resources.displayMetrics.widthPixels
            val label = (node.contentDescription?.toString() ?: node.text?.toString() ?: "Liked video").take(70)
            if (bounds.width() > screenW / 5 && bounds.height() > screenH / 12 &&
                bounds.centerY() in 0 until screenH && bounds.centerX() in 0 until screenW) {
                if (queue.none { kotlin.math.abs(it.x - bounds.centerX()) < 24 && kotlin.math.abs(it.y - bounds.centerY()) < 24 }) {
                    queue.add(QueuedTile(bounds.centerX(), bounds.centerY(), label))
                    Toast.makeText(this, "Added: $label (${queue.size})", Toast.LENGTH_SHORT).show()
                }
            }
            root?.recycle()
        } catch (_: Exception) {
            // Ignore stale accessibility nodes rather than crashing the service.
        } finally {
            node.recycle()
        }
    }
    override fun onInterrupt() { stopQueue() }

    fun setSelectionMode(enabled: Boolean) {
        selecting = enabled
        Toast.makeText(this, if (enabled) "Tap liked-video tiles to add them" else "Selection paused", Toast.LENGTH_SHORT).show()
    }
    fun queueSize() = queue.size
    fun clearQueue() { stopQueue(); queue.clear() }

    fun startQueue() {
        if (running || queue.isEmpty()) {
            Toast.makeText(this, if (queue.isEmpty()) "Queue is empty" else "Already running", Toast.LENGTH_SHORT).show()
            return
        }
        selecting = false
        running = true
        // Bottom-most tiles first reduces the chance that a changing grid shifts later coordinates.
        val ordered = queue.sortedByDescending { it.y }
        queue.clear(); queue.addAll(ordered)
        index = 0
        doNext()
    }

    private fun doNext() {
        if (!running) return
        if (index >= queue.size) {
            running = false
            Toast.makeText(this, "Queue finished", Toast.LENGTH_LONG).show()
            return
        }
        val tile = queue[index]
        tap(tile.x, tile.y) {
            handler.postDelayed({ unlikeCurrentOrSkip() }, 1300)
        }
    }

    private fun unlikeCurrentOrSkip() {
        if (!running) return
        val root = rootInActiveWindow
        if (root == null) { nextAfterBack(); return }
        val button = findUnlike(root)
        root.recycle()
        if (button == null) {
            Toast.makeText(this, "Like control not recognized; skipped", Toast.LENGTH_SHORT).show()
            nextAfterBack()
        } else {
            try { button.performAction(AccessibilityNodeInfo.ACTION_CLICK) } catch (_: Exception) {}
            button.recycle()
            handler.postDelayed({ nextAfterBack() }, 700)
        }
    }

    private fun findUnlike(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val combined = "$desc $txt"
        if (node.isClickable && listOf("unlike", "remove from liked", "remove like", "liked").any { combined.contains(it) })
            return AccessibilityNodeInfo.obtain(node)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = try { findUnlike(child) } catch (_: Exception) { null }
            child.recycle()
            if (result != null) return result
        }
        return null
    }

    private fun nextAfterBack() {
        if (!running) return
        performGlobalAction(GLOBAL_ACTION_BACK)
        handler.postDelayed({ index++; doNext() }, 1100)
    }

    private fun tap(x: Int, y: Int, done: () -> Unit) {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90)).build()
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) { done() }
            override fun onCancelled(gestureDescription: GestureDescription?) { if (running) handler.postDelayed({ doNext() }, 700) }
        }, null)
    }

    fun stopQueue() {
        running = false
        handler.removeCallbacksAndMessages(null)
        Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
    }
    override fun onDestroy() { stopQueue(); instance = null; super.onDestroy() }
}
