# TikTok Unlike Assistant v2

This revision adds a movable floating bubble, a compact control panel, a Select mode, a queue counter, clearer typography, and a custom launcher icon.

## Important safety and reliability notes
This is an experimental accessibility automation project, not an official TikTok integration. It does not log in, collect credentials, or make network requests. Accessibility permission can read screen content and perform taps, so inspect the source and enable it only if you trust it.

### Selection flow
1. Open TikTok → Profile → Liked videos.
2. Open the floating heart bubble and tap SELECT.
3. Tap the liked-video tiles you want to queue. The service listens for accessibility click events and records the clicked tile's screen position.
4. Tap Done selecting, review the queue count, then start only if the selection is correct.

The queue stores screen coordinates, not TikTok video IDs. TikTok layout changes, accessibility labels, screen scaling, overlays, ads, and grid reflow can cause misses or incorrect targets. The automation attempts to open queued positions and clicks only a clickable control whose label contains a recognized “liked/unlike” phrase. If TikTok does not expose such a label, it skips the item. Test with one non-important like first and keep STOP available. Do not leave the automation unattended.

## Build
Use GitHub Actions with JDK 17 and Gradle 8.9. The project is compatible with Android Gradle Plugin 8.7.3 and Kotlin 2.0.21. Build with `gradle assembleDebug`.

## Play Protect
A sideloaded debug APK may trigger Play Protect warnings, especially because it requests Accessibility and overlay capabilities. This is not proof of malware, but the permissions are powerful. Do not disable security scanning or bypass a warning unless you have reviewed and trust the source. For broader distribution, use a properly signed release build and appropriate store review.
